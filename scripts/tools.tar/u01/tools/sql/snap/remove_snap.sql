rem snap v1.1 fritshoogland 14112010
drop table snaptemp;
drop procedure bsnap;
drop procedure esnap;
drop procedure ssnap;
